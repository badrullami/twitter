<?php

class JobController extends BaseController {

	/*
	|--------------------------------------------------------------------------
	| Default Home Controller
	|--------------------------------------------------------------------------
	|
	| You may wish to use controllers instead of, or in addition to, Closure
	| based routes. That's great! Here is an example controller method to
	| get you started. To route to this controller, just add the route:
	|
	|	Route::get('/', 'HomeController@showWelcome');
	|
	*/

	public function follow()
	{
		$follow_config = Configuration::where('configuration_name', '=', 'follow')->first(); 

		if($follow_config->active_job){

			$contents = File::get('follower/follow');
			$list = explode(",", $contents);

			$content_update = array();
			$index = 1;
			$index_update = 0;
			$success = 0;
			$failed = 0;

			foreach ($list as $row) {
				if($row){
					if($index <= $follow_config->limit){
						sleep(2);
						
						$params = array(
							'user_id' 	=> $row,
							'follow'	=> true
							);

						$response = Twitter::postFollow($params);
						($response) ? $success++ : $failed++;

						///... store at file 
						if(!$response)
						{
							$content_update[$index_update] = $row;
							$index_update++;
						}
						///... end of

						$index++;
					}
					else{
						$content_update[$index_update] = $row;
						$index_update++;
					}
				}
			}

			$job = new JobReport;
			$job->job_name = 'follow';
			$job->success = $success;
			$job->failed = $failed;
			$job->save(); 

			File::put('follower/follow', implode(",", $content_update));
		}
	}

	public function unfollow()
	{
		$unfollow_config = Configuration::where('configuration_name', '=', 'unfollow')->first(); 

		if($unfollow_config->active_job){

			$contents = File::get('follower/unfollow');
			$list = explode(",", $contents);

			$content_update = array();
			$index = 1;
			$index_update = 0;
			$success = 0;
			$failed = 0;

			foreach ($list as $row) {
				if($row){
					if($index <= $unfollow_config->limit){
						sleep(2);
						
						$params = array(
							'user_id' 	=> $row
							);

						$response = Twitter::postUnfollow($params);
						($response) ? $success++ : $failed++;

						///... store 
						if(!$response)
						{
							$content_update[$index_update] = $row;
							$index_update++;
						}
						///... end of

						$index++;
					}
					else{
						$content_update[$index_update] = $row;
						$index_update++;
					}
				}
			}

			$job = new JobReport;
			$job->job_name = 'unfollow';
			$job->success = $success;
			$job->failed = $failed;
			$job->save(); 

			File::put('follower/unfollow', implode(",", $content_update));
		}
	}
}
