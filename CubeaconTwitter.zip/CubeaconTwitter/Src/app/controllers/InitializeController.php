<?php

class InitializeController extends BaseController {

	/*
	|--------------------------------------------------------------------------
	| Default Home Controller
	|--------------------------------------------------------------------------
	|
	| You may wish to use controllers instead of, or in addition to, Closure
	| based routes. That's great! Here is an example controller method to
	| get you started. To route to this controller, just add the route:
	|
	|	Route::get('/', 'HomeController@showWelcome');
	|
	*/

	public function index()
	{
		$display = Display::all();
		$array = array();

		$i=0;
		$maximum_grabbing = 0;

		foreach ($display as $row) {
			$array[$i] = $row->display_name;
			$maximum_grabbing = $row->maximum_grabbing;
			$i++;
		}
		
		$sourcename = implode(",", $array);
		if($display->count() > 0)
			return View::make('pages.initialize.source')
				->with('sourcename', $sourcename)
				->with('maximum_grabbing', $maximum_grabbing);

		return View::make('pages.initialize.source')
			->with('sourcename', $sourcename);
	}

	public function storeDisplay()
	{
		$rules = array(
			'sourcename' => 'required',
			'maximum_grabbing' => 'required'
		);

		$validator = Validator::make(Input::all(), $rules);

		if ($validator->fails()) {
			return Redirect::to('initialize')
				->withErrors($validator);
		}
		else{
			$list = explode(",", Input::get('sourcename'));
			
			Display::truncate();
			
			foreach ($list as $row) {
				$display = new Display;
				$display->display_name = $row;
				$display->maximum_grabbing = Input::get('maximum_grabbing');
				$display->save();		
			}

			return Redirect::to('initialize/grab');
		}

	}

	public function grab()
	{
		$display = Display::all();

		return View::make('pages.initialize.grab')
			->with('display', $display);	
	}

	public function storeGrab()
	{	
		File::delete('follower/follow');
		File::delete('follower/unfollow');
		
		$display = Display::all();

		$resultGrab = array();

		foreach ($display as $row) {
			$params = array(
				'screen_name' => $row->display_name, 
				'count' => $row->maximum_grabbing
			);

			$response = Twitter::getFollowersIds($params);

			if(isset($response)){
				$display_one = Display::where('display_id', '=', $row->display_id)->first();
				$display_one->result_total = count($response->ids);
				$display_one->save();
				
				File::append('follower/follow', implode(",", $response->ids));
				File::append('follower/follow', ",");
				File::append('follower/unfollow', implode(",", $response->ids));
				File::append('follower/unfollow', ",");
			}
			else{
				Session::flash('message_error', 'Response null, something wrong when grabbing follower...');
			}
		}
		return Redirect::to('initialize/result');
	}

	public function result()
	{
		$display = Display::all();

		return View::make('pages.initialize.result')
			->with('display', $display);
	}
}
