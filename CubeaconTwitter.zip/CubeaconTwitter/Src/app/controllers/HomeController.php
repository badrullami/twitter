<?php

class HomeController extends BaseController {

	/*
	|--------------------------------------------------------------------------
	| Default Home Controller
	|--------------------------------------------------------------------------
	|
	| You may wish to use controllers instead of, or in addition to, Closure
	| based routes. That's great! Here is an example controller method to
	| get you started. To route to this controller, just add the route:
	|
	|	Route::get('/', 'HomeController@showWelcome');
	|
	*/

	public function index()
	{
		if(Session::has('is_login')){
			return Redirect::to('dashboard');
		}
		
		return View::make('pages.login');
	}

	public function home()
	{
		return View::make('pages.home');
	}

	public function login()
	{
		$rules = array(
			'password' => 'required|alphaNum|min:3'
		);

		$validator = Validator::make(Input::all(), $rules);

		if ($validator->fails()) {
			return Redirect::to('/')
				->withErrors($validator);
		}
		else{
			
			if(md5('cubeacontwitter'.Input::get('password')) == '89246b971e2a08e72a994966f56c1a7f'){
				
				$user = array('fullname' => 'Administrator');

				Session::put('is_login', true);
				
				return Redirect::to('dashboard');
			}
			else{

				Session::flash('message_error', 'Wrong password');

				return Redirect::to('/')
					->withErrors($validator) 
					->withInput(Input::except('password')); 
			}
		}
	}

	public function logout()
	{
		Session::forget('is_login');
		
		return Redirect::to('/');
	}
}
