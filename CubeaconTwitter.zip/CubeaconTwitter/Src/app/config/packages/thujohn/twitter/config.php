<?php

// You can find the keys here : https://dev.twitter.com/

return array(
	'API_URL'             => 'api.twitter.com',
	'API_VERSION'         => '1.1',
	'USE_SSL'             => true,

	'CONSUMER_KEY'        => 'N426dDagZkHyVlQfAYWkFNNlT',
	'CONSUMER_SECRET'     => 'dm3lBBe3F73TDybrs61Ute43E7mpPjxN81RzrlxX90YLEpnQ7I',
	'ACCESS_TOKEN'        => '2713310191-xpkMos9isyuBfYZA6jQ5XqgA04RMlv6vsZDBrqc',
	'ACCESS_TOKEN_SECRET' => '3x88XMWkJTo5g8iEYdaze4HJjWzwJHzwua1FGi63t188t',
);