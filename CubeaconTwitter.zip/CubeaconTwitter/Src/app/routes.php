<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

Route::get('/', array('uses' => 'HomeController@index'));

Route::put('login', array('uses' => 'HomeController@login'));

Route::get('logout', array('uses' => 'HomeController@logout'));

Route::get('dashboard', array('before' => 'login', 'uses' => 'HomeController@home'));

/** 
Initialize data
**/
Route::get('initialize', array('before' => 'login', 'uses' => 'InitializeController@index'));

Route::post('initialize/source/save', array('before' => 'login', 'uses' => 'InitializeController@storeDisplay'));

Route::get('initialize/grab', array('before' => 'login', 'uses' => 'InitializeController@grab'));

Route::post('initialize/grab/save', array('before' => 'login', 'uses' => 'InitializeController@storeGrab'));

Route::get('initialize/result', array('before' => 'login', 'uses' => 'InitializeController@result'));

/**
Cron Job
**/

Route::get('job/follow' , array('uses' => 'JobController@follow'));

Route::get('job/unfollow' , array('uses' => 'JobController@unfollow'));

/**
Report
**/

Route::get('job/report' , array('uses' => 'ReportController@index'));