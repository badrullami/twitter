<?php

class JobReport extends Eloquent
{
	/**
	 * Table name
	 * @var string
	 */

	protected $table = 'job_report';

	/**
	 * The primary key table used by the model.
	 *
	 * @var string
	 */
	protected $primaryKey = 'job_report_id';
}