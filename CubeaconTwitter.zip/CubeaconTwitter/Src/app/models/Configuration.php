<?php

class Configuration extends Eloquent
{
	/**
	 * Table name
	 * @var string
	 */

	protected $table = 'configuration';

	/**
	 * The primary key table used by the model.
	 *
	 * @var string
	 */
	protected $primaryKey = 'configuration_id';
}