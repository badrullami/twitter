<?php

class Display extends Eloquent
{
	/**
	 * Table name
	 * @var string
	 */

	protected $table = 'display';

	/**
	 * The primary key table used by the model.
	 *
	 * @var string
	 */
	protected $primaryKey = 'display_id';
}