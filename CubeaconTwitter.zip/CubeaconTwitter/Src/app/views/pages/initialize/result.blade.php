@extends('layouts.default')
@section('content')
    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                    Initialize Data - Grab Result
                </header>
                <div class="panel-body">
                    <div class="stepy-tab">
                        <ul id="default-titles" class="stepy-titles clearfix">
                            <li id="default-title-0">
                                <div>Step 1</div>
                            </li>
                            <li id="default-title-1">
                                <div>Step 2</div>
                            </li>
                            <li id="default-title-2" class="current-step">
                                <div>Step 3</div>
                            </li>
                        </ul>
                    </div>
                    {{ Form::open(array('url' => 'initialize/source/save', 'method' => 'POST', 'role' => 'form', 'class' => 'form-horizontal', 'id' => 'default')) }}
                        <fieldset title="Step1" class="step" id="default-step-0">
                        <legend> </legend>
                          <div class="form-group">
                              <label class="col-lg-2 control-label"></label>
                                  <div class="col-lg-8">
                                      <table class="table">
                                        <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Display Name</th>
                                            <th>Maximum Grabbing</th>
                                            <th>Result Total</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @if(isset($display))
                                            @foreach($display as $row)
                                                <tr>
                                                    <td>{{ $row->display_id }}</td>
                                                    <td>{{ $row->display_name }}</td>
                                                    <td>{{ $row->maximum_grabbing }}</td>
                                                    <td>{{ $row->result_total }}</td>
                                                </tr>
                                            @endforeach
                                        @endif
                                        </tbody>
                                    </table>
                                  </div>
                              <label class="col-lg-2 control-label"></label>
                          </div>
                        </fieldset>
                        <a href="{{ URL::to('initialize') }}" class="finish btn btn-danger" value="Finish" style="float:right;">Finish</a>
                    {{ Form::close() }}
                </div>
            </section>
        </div>
    </div>
@stop