@extends('layouts.default')
@section('content')
    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                    Initialize Data - Input Screen Name Twitter
                </header>
                <div class="panel-body">
                    <div class="stepy-tab">
                        <ul id="default-titles" class="stepy-titles clearfix">
                            <li id="default-title-0" class="current-step">
                                <div>Step 1</div>
                            </li>
                            <li id="default-title-1">
                                <div>Step 2</div>
                            </li>
                            <li id="default-title-2">
                                <div>Step 3</div>
                            </li>
                        </ul>
                    </div>
                    {{ Form::open(array('url' => 'initialize/source/save', 'method' => 'POST', 'role' => 'form', 'class' => 'form-horizontal', 'id' => 'default')) }}
                        <fieldset title="Step1" class="step" id="default-step-0">
                        <legend> </legend>
                          <div class="form-group">
                              <label class="col-lg-2 control-label"></label>
                              <div class="col-lg-8">
                                  <div class="panel-body">
                                      <input name="sourcename" id="tagsinput" class="tagsinput form-control"  value="{{ (isset($sourcename) ? $sourcename : '') }}" required />
                                      <span class="help-block">This is screen name twitter that grabbed the followers inside...</span>
                                  </div>
                              </div>
                              <label class="col-lg-2 control-label"></label>
                          </div>
                          <div class="form-group">
                              <label class="col-lg-2 control-label"></label>
                              <div class="col-lg-3">
                                  <div class="panel-body">
                                      <input name="maximum_grabbing" type="text" placeholder="" data-mask="99999" class="form-control" value="{{ (isset($maximum_grabbing)) ? $maximum_grabbing : '' }}" required>
                                      <span class="help-block">Input maximum grabbing follower...</span>
                                  </div>
                              </div>
                              <label class="col-lg-2 control-label"></label>
                          </div>
                        </fieldset>
                        <input type="submit" class="btn btn-info" value="Next" style="float:right;"/>
                    {{ Form::close() }}
                </div>
            </section>
        </div>
    </div>
@stop
@section('script')
  {{ HTML::script('themes/js/jquery.tagsinput.js') }}
  {{ HTML::script('themes/js/form-component.js') }}
  {{ HTML::script('themes/assets/bootstrap-inputmask/bootstrap-inputmask.min.js') }}
@stop