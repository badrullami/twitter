@extends('layouts.login')
@section('content')
	<div class="lock-wrapper">
        <div id="time"></div>
        <div class="lock-box text-center">
            {{ HTML::image('themes/img/follower-avatar.jpg', '') }}
            <h1>Administrator</h1>
            <span class="locked">Locked</span>
            {{ Form::open(array('url' => 'login', 'method' => 'PUT','role' => 'form', 'class' => 'form-inline')) }}
                <div class="form-group col-lg-12">
                    <input type="password" placeholder="Password" id="exampleInputPassword2" class="form-control lock-input" name="password">
                    <button class="btn btn-lock" type="submit">
                        <i class="icon-arrow-right"></i>
                    </button>
                </div>
            {{ Form::close() }}
        </div>
    </div>
@stop
@section('script')
    <script>
        function startTime()
        {
            var today=new Date();
            var h=today.getHours();
            var m=today.getMinutes();
            var s=today.getSeconds();
            // add a zero in front of numbers<10
            m=checkTime(m);
            s=checkTime(s);
            document.getElementById('time').innerHTML=h+":"+m+":"+s;
            t=setTimeout(function(){startTime()},500);
        }

        function checkTime(i)
        {
            if (i<10)
            {
                i="0" + i;
            }
            return i;
        }
    </script>
@stop