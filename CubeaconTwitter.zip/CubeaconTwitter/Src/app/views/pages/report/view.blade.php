@extends('layouts.default')
@section('style')
    {{ HTML::style('themes/assets/advanced-datatable/media/css/demo_page.css') }}
    {{ HTML::style('themes/assets/advanced-datatable/media/css/demo_table.css') }}
@stop

@section('content')
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Job Scheduler Report
            </header>
            <div class="panel-body">
                <div class="adv-table">
                    <table  class="display table table-bordered table-striped" id="example">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Job Name</th>
                                <th>Success</th>
                                <th>Failed</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                          @if(isset($report))
                              @foreach($report as $row)
                                  <tr>
                                      <td>{{ $row->job_report_id }}</td>
                                      <td>{{ $row->job_name }}</td>
                                      <td>{{ $row->success }}</td>
                                      <td>{{ $row->failed }}</td>
                                      <td>{{ date('d/m/Y h:s', strtotime($row->created_at)) }}</td>
                                  </tr>
                              @endforeach
                          @endif
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>No</th>
                                <th>Job Name</th>
                                <th>Success</th>
                                <th>Failed</th>
                                <th>Date</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </section>
    </div>
</div>
@stop

@section('script')
    {{ HTML::script('themes/assets/advanced-datatable/media/js/jquery.dataTables.js') }}
    <script type="text/javascript" charset="utf-8">
        $(document).ready(function() {
            $('#example').dataTable( {
                "aaSorting": [[ 4, "desc" ]]
            } );
        } );
    </script>
@stop