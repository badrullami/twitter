@extends('layouts.default')
@section('content')
@stop