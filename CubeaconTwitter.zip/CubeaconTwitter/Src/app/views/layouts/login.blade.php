<!DOCTYPE html>
<html lang="en">
<head>
    @include('includes.head')

</head>

  <body class="lock-screen" onload="startTime()">
  	@include('includes.message')
    @yield('content')
    @include('includes.footer')
    @yield('script')
  </body>
</html>
