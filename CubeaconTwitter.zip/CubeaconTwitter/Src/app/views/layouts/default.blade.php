<!DOCTYPE html>
<html lang="en">
<head>
    @include('includes.head')

</head>

  <body>
    <section id="container" class="">
      @include('includes.header')
      @yield('style')
      @include('includes.sidebar')

      <section id="main-content">
          <section class="wrapper site-min-height">
              @include('includes.message')
              @yield('content')
          </section>
      </section>

      <footer class="site-footer">
          <div class="text-center">
              2014 &copy; Cubeacon.
              <a href="#" class="go-top">
                  <i class="icon-angle-up"></i>
              </a>
          </div>
      </footer>
      
  </section>
    @include('includes.footer')
    @yield('script')
  </body>
</html>
