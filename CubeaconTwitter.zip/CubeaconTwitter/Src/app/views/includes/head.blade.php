<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<link rel="shortcut icon" href="img/favicon.png">

<title>Cubeacon Twitter</title>

{{ HTML::style('themes/css/bootstrap.min.css') }}
{{ HTML::style('themes/css/bootstrap-reset.css') }}
{{ HTML::style('themes/assets/font-awesome/css/font-awesome.css') }}
{{ HTML::style('themes/css/style.css') }}
{{ HTML::style('themes/css/style-responsive.css') }}