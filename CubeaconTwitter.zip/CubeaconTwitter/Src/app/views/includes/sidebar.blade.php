<aside>
    <div id="sidebar"  class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
            <li>
                <a href="#">
                    <i class="icon-dashboard"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li>
                <a href="{{ URL::to('initialize') }}" >
                    <i class="icon-tasks"></i>
                    <span>Initialize Data</span>
                </a>
            </li>
            <li class="sub-menu">
                <a href="javascript:;">
                    <i class="icon-calendar"></i>
                    <span>Cron Scheduler</span>
                </a>
                <ul class="sub">
                    <li><a  href="#">Follow</a></li>
                    <li><a  href="#">Un Follow</a></li>
                    <li><a  href="#">Twitts</a></li>
                </ul>
            </li>
            <li>
                <a href="{{ URL::to('job/report') }}" >
                    <i class="icon-calendar"></i>
                    <span>Job Scheduler Report</span>
                </a>
            </li>                  
        </ul>
        <!-- sidebar menu end-->
    </div>
</aside>