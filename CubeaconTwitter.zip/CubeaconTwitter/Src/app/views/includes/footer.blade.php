{{ HTML::script('themes/js/jquery.js') }}
{{ HTML::script('themes/js/bootstrap.min.js') }}
{{ HTML::script('themes/js/jquery.dcjqaccordion.2.7.js') }}
{{ HTML::script('themes/js/jquery.scrollTo.min.js') }}
{{ HTML::script('themes/js/jquery.nicescroll.js') }}
{{ HTML::script('themes/js/respond.min.js') }}
{{ HTML::script('themes/js/common-scripts.js') }}
{{ HTML::script('themes/js/jquery.stepy.js') }}
