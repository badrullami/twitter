@if(Session::has('message_error'))
<div class="alert alert-block alert-danger fade in">
  <button data-dismiss="alert" class="close close-sm" type="button">
      <i class="icon-remove"></i>
  </button>
  <strong>Oh snap!</strong> {{ Session::get('message_error') }} &hellip;
</div>
@elseif($errors->any())
<div class="alert alert-block alert-danger fade in">
  <button data-dismiss="alert" class="close close-sm" type="button">
      <i class="icon-remove"></i>
  </button>
  {{ HTML::ul($errors->all()) }}
</div>
@elseif(Session::has('message_success'))
<div class="alert alert-success fade in">
  <button data-dismiss="alert" class="close close-sm" type="button">
      <i class="icon-remove"></i>
  </button>
  <strong>Well done!</strong> {{ Session::get('message_success') }} &hellip;
</div>
@elseif(Session::has('message_info'))
<div class="alert alert-info fade in">
  <button data-dismiss="alert" class="close close-sm" type="button">
      <i class="icon-remove"></i>
  </button>
  <strong>Heads up!</strong> {{ Session::get('message_info') }} &hellip;
</div>
@endif